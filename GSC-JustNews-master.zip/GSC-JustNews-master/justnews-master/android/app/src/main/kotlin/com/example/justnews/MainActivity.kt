package com.example.justnews

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
